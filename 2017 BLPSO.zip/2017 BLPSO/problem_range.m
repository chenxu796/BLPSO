
n = D;

lu = [-100 * ones(1, n); 100 * ones(1, n)];

 