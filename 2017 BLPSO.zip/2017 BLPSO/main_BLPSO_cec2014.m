%************************************************************************************************** 
%  BLPSO: Biogeography-Based Learning Particle Swarm Optimization  
%  version: BLPSO 1.1,  Also call BLPSO with refreshing gap  
%  Note: (1) This version uses the refreshing gap to reduce the computation time.  It can reduce the call of function LearnIndex_BLPSO.m
%        (2) The refreshing gap is also used in CLPSO. So the computation time of BLPSO and CLPSO are almost the same.
%  Date: 2017/11/25

% Note:  Although the paper " Biogeography-based learning particle swarm optimization.  Soft Computing 21.24 (2017): 7519-7541." 
%        uses the code of BLPSO1.0, we recommend the BLPSO1.1 as the standard BLPSO.
%**************************************************************************************************


clc;
clear all;  
format long; 

benchmark_cec2014 = str2func('cec14_func'); 
fun = benchmark_cec2014;

for problem = 1:1


    Number = 1;
    runNumber = 1;  % The total number of runs 

    while Number <= runNumber

        tic 
        rand('seed', sum(100 * clock)); 
   
        D = 30;
        lu = [-100 * ones(1, D); 100 * ones(1, D)];
        Xmin = lu(1,:);
        Xmax = lu(2,:);   
    
        % == == == == == parameters setting for BLPSO == == == == == %
        % BLPSO parameters
        popsize = 40 ; 
        maxFES = 1e4*D ; 
        maxGEN = maxFES/popsize; 
        iwt = 0.9 - (1 : maxGEN) * (0.7 / maxGEN);
        c = 1.49445;
        I = 1; % max immigration rate 
        E = 1; % max emigration rate 
        
        % Compute migration rates, assuming the population is sorted from most fit to least fit
        MigrateModel = 5;
        migration_models;
        
        % Initialize the main population
        X = repmat(Xmin, popsize, 1) + rand(popsize,D) .* (repmat(Xmax-Xmin, popsize, 1));
        val_X = (fun(X',problem))';  
        pBest = X; val_pBest = val_X;  
        [~,indexG] = min(val_pBest);
        gBest = pBest(indexG,:); val_gBest = val_pBest(indexG,:);    
        Vmax = (Xmax - Xmin)*0.2;  Vmin = -Vmax;    
        V = repmat(Vmin,popsize,1) + rand(popsize,D).*repmat(Vmax-Vmin,popsize,1);  
   
        gapm = 5; stay_num = zeros(1,popsize);  
        cc = 0;

        for i = 1:popsize
            pBest_ind(i,:) = LearnIndex_BLPSO(val_pBest,popsize,D,i,mu,lambda); 
        end        
                    
        FES = popsize; GEN = 1;  
        outcome = [];  % record the best results

        while   FES < maxFES  
  
                for i = 1:popsize
                    
                    %  Biogeography-based exemplar selection method
                    if stay_num(i)>gapm 
                        pBest_ind(i,:) = LearnIndex_BLPSO(val_pBest,popsize,D,i,mu,lambda);
                        cc = cc+1; 
                        stay_num(i) = 0;
                    end
  
                    %  Biogeography-based learning updating       
                    for  j=1:D
                        pBest_f(i,j) = pBest(pBest_ind(i,j),j);  
                    end  
                    V(i,:) = iwt(GEN)*V(i,:) + c*rand(1,D).*(pBest_f(i,:)-X(i,:));  % update velocity
                    V(i,:) = boundary_repair(V(i,:),Vmin,Vmax,'absorb');   
                    X(i,:) = X(i,:)+V(i,:);    % update position

                    if all(X(i,:)<=Xmax) & all(X(i,:)>=Xmin)  % X(i,:) is feasible
                        val = (fun(X(i,:)',problem))'; 
                        FES = FES+1;
                        if val<val_pBest(i)    % update pBest
                            pBest(i,:) = X(i,:);  val_pBest(i) = val;
                            stay_num(i) = 0; 
                        else
                            stay_num(i) = stay_num(i)+1;
                        end 
                    end 

                end   


                [~,indexG] = min(val_pBest);
                gBest = pBest(indexG,:); val_gBest = val_pBest(indexG,:);   
                
                FES0 = length(outcome);
                outcome = [outcome; val_gBest*ones((FES-FES0),1)];
                
                if mod(FES,1e4)<41
                disp(sprintf('problem=%d;  Number=%d;  FES=%d;  cc=%d;  val_gBest=%d;',problem,Number,FES,cc,val_gBest)); 
                end
                        

                GEN = GEN+1;
                if (GEN == maxGEN) & (FES < maxFES)
                    GEN = GEN-1;
                end 
        end


        disp(sprintf('problem=%d;  Number=%d;  FES=%d;  cc=%d;  val_gBest=%d;  runtime=%d;',problem,Number,FES,cc,val_gBest,toc));   

%       record data 
        eval(['record.outcome',num2str(Number),'=','outcome',';']);
        record.FES(Number) = FES;
        record.time(Number) = toc; 
        
        Number = Number + 1;  
        
    end

    % save results 
    filename = strcat( 'out_cec2014_D',num2str(D),'_f', num2str(problem),'_BLPSO');  
    save(filename, 'record'); 
 
end





