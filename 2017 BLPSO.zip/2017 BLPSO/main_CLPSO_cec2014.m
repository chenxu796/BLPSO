%************************************************************************************************** 
%  CLPSO�� Comprehensive Learning Particle Swarm Optimizer for Global Optimization of Multimodal Functions
%  We obtained the MATLAB source code from the authors
%  Date: 2014/11/14
%**************************************************************************************************


clc;
clear all;  
format long;  

benchmark_cec2014 = str2func('cec14_func'); 
fun = benchmark_cec2014;

for problem = 1:1

    D = 30;
    lu = [-100 * ones(1, D); 100 * ones(1, D)];
    Xmin = lu(1,:);
    Xmax = lu(2,:);  

    Number = 1;
    runNumber = 1;  % The total number of runs 

    while Number <= runNumber

        tic 
        rand('seed', sum(100 * clock)); 
   
        % parameters setting for CLPSO
        popsize = 40; 
        maxFES = 1e4*D;
        maxGEN = maxFES/popsize; 
        iwt = 0.9 - (1 : maxGEN) * (0.7 / maxGEN);
        c = 1.49445;
        
        % Initialize the main population
        X = repmat(Xmin, popsize, 1) + rand(popsize,D) .* (repmat(Xmax-Xmin, popsize, 1));
        val_X = (fun(X',problem))';  
        pBest = X; val_pBest = val_X;  
        [~,indexG] = min(val_pBest);
        gBest = pBest(indexG,:); val_gBest = val_pBest(indexG,:);    
        Vmax = (Xmax - Xmin)*0.2;  Vmin = -Vmax;    
        V = repmat(Vmin,popsize,1) + rand(popsize,D).*repmat(Vmax-Vmin,popsize,1);
        
        % Learning Probability Pc
        t = 0 : 1/(popsize-1):1;
        t = 5.*t;
        Pc = 0.0+(0.5-0.0).*(exp(t)-exp(t(1)))./(exp(t(popsize))-exp(t(1)));
        
        % Refreshing Gap
        gapm = 5; stay_num = zeros(1,popsize); 
        for i = 1:popsize
            pBest_ind(i,:) = LearnIndex_CLPSO(val_pBest,popsize,D,i,Pc(i));
        end 
                 
        FES = 0; GEN = 1;  
        outcome = [];  % record the best results

        while   FES < maxFES  
  
                for i = 1:popsize
                    
                    % update exemplar index
                    if stay_num(i)>gapm   
                        pBest_ind(i,:) = LearnIndex_CLPSO(val_pBest,popsize,D,i,Pc(i));
                        stay_num(i) = 0;
                    end 

                    %  Compehensive Learning Strategy       
                    for  j=1:D
                        pBest_f(i,j) = pBest(pBest_ind(i,j),j);  
                    end  
                    V(i,:) = iwt(GEN)*V(i,:) + c*rand(1,D).*(pBest_f(i,:)-X(i,:));  % update velocity
                    V(i,:) = boundary_repair(V(i,:),Vmin,Vmax,'absorb');   
                    X(i,:) = X(i,:)+V(i,:);    % update position

                    if all(X(i,:)<=Xmax) & all(X(i,:)>=Xmin)  % X(i,:) is feasible
                        val = (fun(X(i,:)',problem))'; 
                        FES = FES+1;
                        if val<val_pBest(i)    % update pBest
                            pBest(i,:) = X(i,:);  val_pBest(i) = val;
                            stay_num(i) = 0;
                        else
                            stay_num(i) = stay_num(i)+1;
                        end 
                    end 

                end  
 
                [~,indexG] = min(val_pBest);
                gBest = pBest(indexG,:); val_gBest = val_pBest(indexG,:);   

                 FES0 = length(outcome);
                outcome = [outcome; val_gBest*ones((FES-FES0),1)];

                
                if mod(FES,1e4)<41
                    disp(sprintf('problem=%d;  Number=%d;  FES=%d; val_gBest=%d;',problem,Number,FES,val_gBest)); 
                end
                
                if FES >= maxFES
                    break;
                end
                GEN = GEN+1;
                if (GEN == maxGEN) & (FES < maxFES)
                    GEN = GEN-1;
                end 

                                 
        end

        disp(sprintf('problem=%d;  Number=%d;  FES=%d;  val_gBest=%d;  runtime=%d;',problem,Number,FES,val_gBest,toc)); 


        eval(['record.outcome',num2str(Number),'=','outcome',';']);
        record.FES(Number) = FES;
        record.time(Number) = toc;  
        
        Number = Number + 1;  
        
    end

    % save results 
    filename = strcat( 'out_cec2014_D',num2str(D),'_f', num2str(problem),'_CLPSO');  
    save(filename, 'record'); 
 
end





