%************************************************************************************************** 
%  Biogeography-based learning particle swarm optimization.  Soft Computing 21.24 (2017): 7519-7541." 
%  BLPSO1.0:  The code of BLPSO in Soft Computing 
%  Date: 2015/5/15
%**************************************************************************************************


clc;
clear all;  
format long; 

benchmark_cec2014 = str2func('cec14_func'); 
fun = benchmark_cec2014;

for problem = 1:1


    Number = 1;
    runNumber = 1;  % The total number of runs 

    while Number <= runNumber

        tic 
        rand('seed', sum(100 * clock)); 
   
        D = 30;
        lu = [-100 * ones(1, D); 100 * ones(1, D)];
        Xmin = lu(1,:);
        Xmax = lu(2,:);   
    
        % == == == == == parameters setting for BLPSO == == == == == %
        popsize = 40 ; 
        maxFES = 1e4*D ; 
        maxGEN = maxFES/popsize; 
        iwt = 0.9 - (1 : maxGEN) * (0.7 / maxGEN);
        c = 1.49445;
        % BBO parameters
        I = 1; % max immigration rate 
        E = 1; % max emigration rate 
        
        % Compute migration rates, assuming the population is sorted from most fit to least fit
        MigrateModel = 5;
        migration_models;
        
        % Initialize the main population
        X = repmat(Xmin, popsize, 1) + rand(popsize,D) .* (repmat(Xmax-Xmin, popsize, 1));
        val_X = (fun(X',problem))';  
        pBest = X; val_pBest = val_X;  
        [~,indexG] = min(val_pBest);
        gBest = pBest(indexG,:); val_gBest = val_pBest(indexG,:);    
        Vmax = (Xmax - Xmin)*0.2;  Vmin = -Vmax;    
        V = repmat(Vmin,popsize,1) + rand(popsize,D).*repmat(Vmax-Vmin,popsize,1);  
   
                 
        FES = popsize; GEN = 1;  
        outcome = [];  % record the best results 
 

        while   FES < maxFES  
  
                for i = 1:popsize
                    
                    %  Biogeography-based exemplar selection method
                    pBest_ind(i,:) = LearnIndex_BLPSO(val_pBest,popsize,D,i,mu,lambda);
  
                    %  Biogeography learning updating       
                    for  j=1:D
                        pBest_f(i,j) = pBest(pBest_ind(i,j),j);  
                    end  
                    V(i,:) = iwt(GEN)*V(i,:) + c*rand(1,D).*(pBest_f(i,:)-X(i,:));  % update velocity
                    V(i,:) = boundary_repair(V(i,:),Vmin,Vmax,'absorb');   
                    X(i,:) = X(i,:)+V(i,:);    % update position

                    if all(X(i,:)<=Xmax) & all(X(i,:)>=Xmin)  % X(i,:) is feasible
                        val = (fun(X(i,:)',problem))'; 
                        FES = FES+1;
                        if val<val_pBest(i)    % update pBest
                            pBest(i,:) = X(i,:);  val_pBest(i) = val; 
                         end 
                    end 

                end   

                [~,indexG] = min(val_pBest);
                gBest = pBest(indexG,:); val_gBest = val_pBest(indexG,:);   
        
                FES0 = length(outcome);
                outcome = [outcome; val_gBest*ones((FES-FES0),1)];
                
                if mod(FES,1e4)<41
                    disp(sprintf('problem=%d;  Number=%d;  FES=%d;  val_gBest=%d;',problem,Number,FES,val_gBest)); 
                end
                        

                GEN = GEN+1;
                if (GEN == maxGEN) & (FES < maxFES)
                    GEN = GEN-1;
                end 
                
        end 

        disp(sprintf('problem=%d;  Number=%d;  FES=%d;  val_gBest=%d;  runtime=%d;',problem,Number,FES,val_gBest,toc));   

%       record data 
        eval(['record.outcome',num2str(Number),'=','outcome',';']);
        record.FES(Number) = FES;
        record.time(Number) = toc; 
        
        Number = Number + 1;  
        
    end

    % save results 
    filename = strcat( 'out_cec2014_D',num2str(D),'_f', num2str(problem),'_BLPSO');  
    save(filename, 'record'); 
 
end





