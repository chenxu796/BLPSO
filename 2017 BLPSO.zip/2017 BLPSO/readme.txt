
1 CLPSO

2 BLPSO 1.0

3 BLPSO 1.1
    BLPSO with refreshing gap 
    Note: (1) This version uses the refreshing gap to reduce the computation time.  It can reduce the call of function LearnIndex_BLPSO.m
          (2) The refreshing gap is also used in CLPSO. So the computation time of BLPSO and CLPSO are almost the same. 

Although the paper " Biogeography-based learning particle swarm optimization.  Soft Computing 21.24 (2017): 7519-7541." uses the code of BLPSO1.0, we recommend the BLPSO 1.1   as the standard BLPSO.
